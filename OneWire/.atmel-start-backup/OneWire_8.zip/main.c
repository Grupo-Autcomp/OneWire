#include <atmel_start.h>
#include <util/delay.h>

typedef struct {
	volatile uint8_t R_reg;
	volatile uint8_t G_reg;
	volatile uint8_t B_reg;
} LED;

volatile LED LED_Display[1] = {
	{0x55, 0x00, 0xFF}
};

uint32_t convert_string(uint8_t color);

volatile uint32_t data_R;
volatile uint32_t data_G;
volatile uint32_t data_B;
volatile uint32_t data;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	data_R = convert_string(LED_Display->R_reg);
	//data_G = convert8to32(LED_Display->G_reg);
	//data_B = convert8to32(LED_Display->B_reg);
	
	data |= 0x00000008 << (7*4);
	data |= 0x0000000E << (6*4);
	data |= 0x00000008 << (5*4);
	data |= 0x0000000E << (4*4);
	data |= 0x00000008 << (3*4);
	data |= 0x0000000E << (2*4);
	data |= 0x00000008 << (1*4);
	data |= 0x0000000E << (0*4);
	
	/* Replace with your application code */
	while (1) {
		//SPI_0_write_block(data_R, 32);
		//SPI_0_write_block(data_G, 32);
		//SPI_0_write_block(data_B, 32);
		
		LED0_toggle_level();
		_delay_ms(100);
		
	}
}

uint32_t convert_string(uint8_t color){
	
	uint32_t data = 0x00000000;
	uint32_t logic;
	int8_t i = 7;
	uint8_t condition;
	uint32_t step = 0x00000000;
	
	//while(i>=0){
		//step = 1 << i;
		//condition = color & step;
		
		//step = 1 << i*4;
		//if (condition) {
			//logic = 0x0000000E << (i*4);
			//data |= logic;
		//}
		//else{
			//logic = 0x00000008 << (i*4);
			//data |= logic;
		//}
		//i--;
	//}
	
	data |= 0x00000008 << (7*4);
	data |= 0x0000000E << (6*4);
	data |= 0x00000008 << (5*4);
	data |= 0x0000000E << (4*4);
	data |= 0x00000008 << (3*4);
	data |= 0x0000000E << (2*4);
	data |= 0x00000008 << (1*4);
	data |= 0x0000000E << (0*4);
	
	
	return data;
}